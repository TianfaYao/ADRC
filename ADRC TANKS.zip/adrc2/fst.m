function f=fst(x,a,b)

   f=((abs(x-a)-abs(x-b))/(b-a)+1)/2;