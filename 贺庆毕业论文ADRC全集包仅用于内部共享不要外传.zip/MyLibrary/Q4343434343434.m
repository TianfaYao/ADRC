
plot(out,'DisplayName','out','YDataSource','out');figure(gcf);subplot(2,1,1)
plot(in,'DisplayName','in','YDataSource','in');figure(gcf);subplot(2,1,2)