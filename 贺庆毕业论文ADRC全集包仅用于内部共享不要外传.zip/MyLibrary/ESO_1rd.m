function [ output_args ] = ESO_1rd( input_args )
%ESO_1RD Summary of this function goes here
%   Detailed explanation goes here


end

