function y=fsg(x,a,b)
if x>b
    y=0;
elseif x<a
    y=0;
elseif x=a
    y=1/2;
elseif x=b;
    y=1/2;
else y=1;
end
