function [ output_args ] = ESO_3rd( input_args )
%ESO_3RD Summary of this function goes here
%   Detailed explanation goes here


end

